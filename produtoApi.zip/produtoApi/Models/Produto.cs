﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RequiredAttribute = System.ComponentModel.DataAnnotations.RequiredAttribute;

namespace produtoApi.Models
{
    [Table("TbProduto")]
    public class Produto
    {
        [Key]
        [Required]
        [Display(Name="ID Produto")]
        public int ProdutoId { get; set; }

        [Required]
        [Display(Name = "Codido do Produto")]
        public int CodigoId { get; set; }

        [StringLength(200)]
        [Display(Name = "Modelo")]
        public string Modelo { get; set; }

        [StringLength(100)]
        [Display(Name = "Cor")]
        public string Cor { get; set; }

        [StringLength(200)]
        [Display(Name = "Descricao")]
        public string Descricao { get; set; }

        [StringLength(200)]
        [Display(Name = "Fornecedor")]
        public string Fornecedor { get; set; }

        [Required]
        [Display(Name = "Imagem")]
        public string ContentTYPE { get; set; }

        [Required]
        [Display(Name = "Carregar Foto")]
        public byte[] Imagem { get; set; }
      
    }
}