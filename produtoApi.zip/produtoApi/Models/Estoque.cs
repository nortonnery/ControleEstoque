﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace produtoApi.Models
{
    [Table("TbEstoque")]
    public class Estoque
    {
        [Key]
        [Required]
        [Display(Name = "ID Estoque")]
        public int DadosProdutoId { get; set; }

        [Display(Name = "Quantidade")]
        public int Quantidade { get; set; }

        [Display(Name = "Custo")]
        public double Custo { get; set; }

        [Display(Name = "Custo Total")]
        public double CustoTotal { get; set; }

        [Display(Name = "Venda")]
        public double Venda { get; set; }

        [Display(Name = "Venda Total")]
        public double VendaTotal { get; set; }

        [Required]
        public int ProdutoId { get; set; }
    }
}