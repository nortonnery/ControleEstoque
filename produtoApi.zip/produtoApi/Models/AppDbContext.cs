﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace produtoApi.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext() : base("WaldirEntities")
        { }
        public DbSet<Produto> Produto { get; set; }
        public DbSet<Estoque> DadosProdutos { get; set; }
    }
}