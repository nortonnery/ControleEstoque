﻿using produtoApi.Areas.HelpPage.Models;
using produtoApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using HttpGetAttribute = System.Web.Http.HttpGetAttribute;
using HttpPostAttribute = System.Web.Http.HttpPostAttribute;
using HttpPutAttribute = System.Web.Http.HttpPutAttribute;

namespace produtoApi.Areas.HelpPage.Controllers
{
    public class ProdutosController : ApiController
    {
        [HttpGet]
        public IHttpActionResult GetAllProdutos()
        {
            IList<ProdutoViewModel> produto = null;

            using (var ctx = new WaldirEntities())
            {
                produto = ctx.TbProduto.Include("TbProduto")
                            .Select(s => new ProdutoViewModel()
                            {
                                ProdutoId  = s.ProdutoId,
                                CodigoId   = s.CodigoId,
                                Modelo     = s.Modelo,
                                Cor        = s.Cor,
                                Descricao  = s.Descricao,
                                Fornecedor = s.Fornecedor,
                               // ContentTYPE = s.ContentTYPE,
                                Imagem = s.Imagem
                            }).ToList<ProdutoViewModel>();
            }

            if (produto.Count == 0)
            {
                return NotFound();
            }

            return Ok(produto);
        }
        /*
        [HttpGet]
        public IHttpActionResult GetAllProdutosWithEstoque(bool includeEstoque = false)
        {
            IList<ProdutoViewModel> produtos = null;

            using (var ctx = new WaldirEntities())
            {
                produtos = ctx.TbProduto.Include("TbEstoque").Select(s => new ProdutoViewModel()
                {
                    ProdutoId    = s.ProdutoId,
                    CodigoId     = s.CodigoId,
                    Modelo       = s.Modelo,
                    Cor          = s.Cor,
                    Descricao    = s.Descricao,
                    Fornecedor   = s.Fornecedor,
                  //  ContentTYPE  = s.ContentTYPE,
                    Imagem       = s.Imagem
                   //  Estoque      = s.TbEstoque == null || includeEstoque ==false ? null : new EstoqueViewModel()
                   //  {                     
                   //    ProdutoId  = s.TbEstoque.,
                   //    Quantidade = s.TbEstoque.Quantidade,
                   //    Custo      = s.TbEstoque.Custo,
                   //    CustoTotal = s.TbEstoque.CustoTotal,
                   //    Venda      = s.TbEstoque.Venda,
                   //    VendaTotal = s.TbEstoque.VendaTotal
                   //  } 
                }).ToList<ProdutoViewModel>();
            }


            if (produtos.Count == 0)
            {
                return NotFound();
            }

            return Ok(produtos);
        }
*/
        [HttpGet]
        public IHttpActionResult GetProdutoById(int id)
        {
            ProdutoViewModel produto = null;

            using (var ctx = new WaldirEntities())
            {
                produto = ctx.TbProduto.Include("TbProduto")
                    .Where(s => s.ProdutoId == id)
                    .Select(s => new ProdutoViewModel()
                    {
                        ProdutoId = s.ProdutoId,
                        CodigoId = s.CodigoId,
                        Modelo = s.Modelo,
                        Cor = s.Cor,
                        Descricao = s.Descricao,
                        Fornecedor = s.Fornecedor,
                        //  ContentTYPE  = s.ContentTYPE,
                        Imagem = s.Imagem
                    }).FirstOrDefault<ProdutoViewModel>();
            }

            if (produto == null)
            {
                return NotFound();
            }

            return Ok(produto);
        }

        [HttpGet]
        public IHttpActionResult GetAllProdutos(string name)
        {
            IList<ProdutoViewModel> produto = null;

            using (var ctx = new WaldirEntities())
            {
                produto = ctx.TbProduto.Include("TbEstoque")
                    .Where(s => s.Modelo.ToLower() == name.ToLower())
                    .Select(s => new ProdutoViewModel()
                    {
                         ProdutoId = s.ProdutoId,
                        CodigoId = s.CodigoId,
                        Modelo = s.Modelo,
                        Cor = s.Cor,
                        Descricao = s.Descricao,
                        Fornecedor = s.Fornecedor,
                        //  ContentTYPE  = s.ContentTYPE,
                        Imagem = s.Imagem
                       // Estoque = s.TbEstoque == null ? null : new EstoqueViewModel()
                       // {
                       //     ProdutoId = s.TbEstoque.,
                       //     Quantidade = s.TbEstoque.Quantidade,
                       //     Custo = s.TbEstoque.Custo,
                       //     CustoTotal = s.TbEstoque.CustoTotal,
                       //     Venda = s.TbEstoque.Venda,
                       //     VendaTotal = s.TbEstoque.VendaTotal
                       // }
                    }).ToList<ProdutoViewModel>();
            }

            if (produto.Count == 0)
            {
                return NotFound();
            }

            return Ok(produto);
        }

        [HttpPost]
        //Get action methods of the previous section
        public IHttpActionResult Post(ProdutoViewModel produto)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");

            using (var ctx = new WaldirEntities())
            {
                ctx.TbProduto.Add(new TbProduto()
                {
                    //  ProdutoId = produto.ProdutoId,
                    CodigoId = produto.CodigoId,
                    Modelo = produto.Modelo,
                    Cor = produto.Cor,
                    Descricao = produto.Descricao,
                    Fornecedor = produto.Fornecedor,
                    //  ContentTYPE = produto.ContentTYPE,
                   /// ContentTYPE = teste,
                    Imagem = produto.Imagem

                }); ;

                ctx.SaveChanges();
            }

            return Ok();
        }

        [HttpPut]
        public IHttpActionResult Put(ProdutoViewModel produto)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            using (var ctx = new WaldirEntities())
            {
                var existingProduto = ctx.TbProduto.Where(s => s.ProdutoId == produto.ProdutoId)
                                                        .FirstOrDefault<TbProduto>();

                if (existingProduto != null)
                {
                    existingProduto.Descricao = produto.Descricao;
                    existingProduto.Cor = produto.Cor;
                    existingProduto.Fornecedor = produto.Fornecedor;
                    existingProduto.Modelo = produto.Modelo;
                    existingProduto.Imagem = produto.Imagem;
                   // existingProduto.ContentType= produto.ContentType;

                    ctx.SaveChanges();
                }
                else
                {
                    return NotFound();
                }
            }

            return Ok();
        }
        public IHttpActionResult Delete(int id)
        {
            if (id <= 0)
                return BadRequest("Codigo de Produto Invalido");

            using (var ctx = new WaldirEntities())
            {
                var produto = ctx.TbProduto
                    .Where(s => s.ProdutoId == id)
                    .FirstOrDefault();

                ctx.Entry(produto).State = System.Data.Entity.EntityState.Deleted;
                ctx.SaveChanges();
            }

            return Ok();
        }
    }
}
