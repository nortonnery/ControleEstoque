﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace produtoApi.Areas.HelpPage.Models
{
    public class ProdutoViewModel
    {
        public int ProdutoId { get; set; }

        public int CodigoId { get; set; }

        public string Modelo { get; set; }

        public string Cor { get; set; }

        public string Descricao { get; set; }

        public string Fornecedor { get; set; }

        public string ContentTYPE { get; set; }

        [Display(Name = "Carregar Foto")]
        public byte[] Imagem { get; set; }

        public EstoqueViewModel Estoque { get; set; }
    }
}