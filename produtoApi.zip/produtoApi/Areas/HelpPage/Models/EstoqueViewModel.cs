﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace produtoApi.Areas.HelpPage.Models
{
    public class EstoqueViewModel
    {
        public int DadosProdutoId { get; set; }

        public int Quantidade { get; set; }

        public double Custo { get; set; }

        public double CustoTotal { get; set; }

        public double Venda { get; set; }

        public double VendaTotal { get; set; }

        public int ProdutoId { get; set; }
    }
}