﻿using produtoApi.Areas.HelpPage.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using ActionNameAttribute = System.Web.Http.ActionNameAttribute;
using HttpDeleteAttribute = System.Web.Http.HttpDeleteAttribute;
using HttpGetAttribute = System.Web.Mvc.HttpGetAttribute;
using HttpPostAttribute = System.Web.Http.HttpPostAttribute;
using HttpPutAttribute = System.Web.Http.HttpPutAttribute;
using RouteAttribute = System.Web.Http.RouteAttribute;
using RoutePrefixAttribute = System.Web.Http.RoutePrefixAttribute;

namespace produtoApi.Controllers
{
    [RoutePrefix("Returns")]
    public class EstoqueController : Controller
    {
        // GET: Estoque
        public ActionResult Index()
        {
            IEnumerable<EstoqueViewModel> estoque = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/");
                //HTTP GET
                var responseTask = client.GetAsync("estoques");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<EstoqueViewModel>>();
                    readTask.Wait();

                    estoque = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    estoque = Enumerable.Empty<EstoqueViewModel>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(estoque);
        }

        [Route("Create")]
        [HttpGet, ActionName("Create")]
        public ActionResult Create()
        {
            return View();
        }

        [Route("Create")]
        [HttpGet, ActionName("Create")]
        public ActionResult Create(int id)
        {
            return View();
        }

        [HttpPost, ActionName("Create")]
        public ActionResult CreateEstoque(EstoqueViewModel estoque)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/");

                //HTTP POST
                var postTask = client.PostAsJsonAsync<EstoqueViewModel>("estoques", estoque);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(estoque);
        }

        [Route("Edit/{id:int}")]
        [HttpGet, ActionName("Edit")]
        public ActionResult Edit(int id)
        {
            EstoqueViewModel estoque = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/");
                //HTTP GET
                var responseTask = client.GetAsync("estoque/" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<EstoqueViewModel>();
                    readTask.Wait();

                    estoque = readTask.Result;
                }
            }

            return View(estoque);
        }

        [HttpPost]
        public ActionResult Edit(EstoqueViewModel estoque)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/Estoques/");

                //HTTP POST
                var putTask = client.PutAsJsonAsync<EstoqueViewModel>("estoque", estoque);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index");
                }
            }
            return View(estoque);
        }

        [Route("Delete/{id:int}")]
        [HttpGet, ActionName("Delete")]
        public ActionResult Delete(int id)
        {
            EstoqueViewModel estoque = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/Estoques");
                //HTTP GET
                var responseTask = client.GetAsync("estoque/" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<EstoqueViewModel>();
                    readTask.Wait();

                    estoque = readTask.Result;
                }
            }

            return View(estoque);
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/estoques");

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("estoque/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index");
                }
            }

            return RedirectToAction("Index");
        }
    }
}