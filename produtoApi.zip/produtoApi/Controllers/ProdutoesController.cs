﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using produtoApi.Areas.HelpPage.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using ActionNameAttribute = System.Web.Mvc.ActionNameAttribute;
using HttpGetAttribute = System.Web.Http.HttpGetAttribute;
using HttpPostAttribute = System.Web.Http.HttpPostAttribute;
using RouteAttribute = System.Web.Mvc.RouteAttribute;
using RoutePrefixAttribute = System.Web.Http.RoutePrefixAttribute;

namespace produtoApi.Controllers
{
    [RoutePrefix("Returns")]
    public class ProdutoesController : Controller
    {
        //Define uma instância de IHostingEnvironment
        IHostingEnvironment _appEnvironment;
        //Injeta a instância no construtor para poder usar os recursos
        public ProdutoesController(IHostingEnvironment env)
        {
            _appEnvironment = env;
        }

        public ProdutoesController()
        {
        }

        // GET: Produtoes
        public ActionResult Index()
        {
            IEnumerable<ProdutoViewModel> produto = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/Produtos");
                //HTTP GET
                var responseTask = client.GetAsync("Produtos");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<ProdutoViewModel>>();
                    readTask.Wait();

                    produto = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    produto = Enumerable.Empty<ProdutoViewModel>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(produto);
        }
        [HttpGet]
        [Route("Create")]
        public ActionResult Create()
        {
           return View();
        }

       // [ValidateAntiForgeryToken]
        [HttpPost, ActionName("Create")]
       // [Route("Create")]
       /// public ActionResult Create(ProdutoViewModel produto)
         public ActionResult Create(ProdutoViewModel produto, HttpPostedFileBase upload)
        {
          //  long tamanhoArquivos = upload.ToString();
            // caminho completo do arquivo na localização temporária
            var caminhoArquivo = Path.GetTempFileName();

         /*   // processa os arquivo enviados
            //percorre a lista de arquivos selecionados
            foreach (var arquivo in upload)
            {
                //verifica se existem arquivos 
                if (arquivo == null || arquivo.Length == 0)
                {
                    //retorna a viewdata com erro
                    ViewData["Erro"] = "Error: Arquivo(s) não selecionado(s)";
                    return View(ViewData);
                }
                // < define a pasta onde vamos salvar os arquivos >
                string pasta = "Arquivos_Usuario";
                // Define um nome para o arquivo enviado incluindo o sufixo obtido de milesegundos
                string nomeArquivo = "Usuario_arquivo_" + DateTime.Now.Millisecond.ToString();
                //verifica qual o tipo de arquivo : jpg, gif, png, pdf ou tmp
                if (arquivo.FileName.Contains(".jpg"))
                    nomeArquivo += ".jpg";
                else if (arquivo.FileName.Contains(".gif"))
                    nomeArquivo += ".gif";
                else if (arquivo.FileName.Contains(".png"))
                    nomeArquivo += ".png";
                else if (arquivo.FileName.Contains(".pdf"))
                    nomeArquivo += ".pdf";
                else
                    nomeArquivo += ".tmp";
                //< obtém o caminho físico da pasta wwwroot >
                string caminho_WebRoot = _appEnvironment.WebRootPath;
                // monta o caminho onde vamos salvar o arquivo : 
                // ~\wwwroot\Arquivos\Arquivos_Usuario\Recebidos
                string caminhoDestinoArquivo = caminho_WebRoot + "\\Arquivos\\" + pasta + "\\";
                // incluir a pasta Recebidos e o nome do arquivo enviado : 
                // ~\wwwroot\Arquivos\Arquivos_Usuario\Recebidos\
                string caminhoDestinoArquivoOriginal = caminhoDestinoArquivo + "\\Recebidos\\" + nomeArquivo;
                //copia o arquivo para o local de destino original
               // using (var stream = new FileStream(caminhoDestinoArquivoOriginal, FileMode.Create))
               // {
               //     await arquivo.CopyToAsync(stream);
               // }
            }
            */
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/");


                //HTTP POST
                var postTask = client.PostAsJsonAsync<ProdutoViewModel>("produtos", produto);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                   /// return RedirectToAction("Index");
                    return RedirectToRoute(new { controller = "Estoque", action = "Create", id = produto.ProdutoId });
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(produto);
        }

        [Route("Edit/{id:int}")]
        public ActionResult Edit(int id)
        {
            ProdutoViewModel produto = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/");
                //HTTP GET
                var responseTask = client.GetAsync("produtos/" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<ProdutoViewModel>();
                    readTask.Wait();

                    produto = readTask.Result;
                }
            }

            return View(produto);
        }

        [HttpPost]
        public ActionResult Edit(ProdutoViewModel produto)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/");

                //HTTP POST
                var putTask = client.PutAsJsonAsync<ProdutoViewModel>("produtos", produto);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index");
                }
            }
            return View(produto);
        }
        
        [Route("Delete/{id:int}")]
        public ActionResult Delete(int id)
        {
            ProdutoViewModel produto = null; ;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/");
                //HTTP GET
                var responseTask = client.GetAsync("produtos/" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<ProdutoViewModel>();
                    readTask.Wait();

                    produto = readTask.Result;
                }
            }

            return View(produto);
        }
           
               
        [HttpPost]
        //[Route("Delete/{id:int}")]
        public ActionResult Delete(ProdutoViewModel produto)      
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53484/api/");

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("produtos/" + produto.ProdutoId.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            return RedirectToAction("Index");
        }
    }
}