﻿namespace produtoApi.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Inicial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Estoques",
                c => new
                    {
                        DadosProdutoId = c.Int(nullable: false, identity: true),
                        Quantidade = c.Int(nullable: false),
                        Custo = c.Double(nullable: false),
                        CustoTotal = c.Double(nullable: false),
                        Venda = c.Double(nullable: false),
                        VendaTotal = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.DadosProdutoId);
            
            CreateTable(
                "dbo.TbProduto",
                c => new
                    {
                        ProdutoId = c.Int(nullable: false, identity: true),
                        CodigoId = c.Int(nullable: false),
                        ModeloProduto = c.String(maxLength: 200),
                        Cor = c.String(maxLength: 100),
                        Descricao = c.String(maxLength: 200),
                        Fornecedor = c.String(maxLength: 200),
                        DadosProdutoId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ProdutoId)
                .ForeignKey("dbo.Estoques", t => t.DadosProdutoId, cascadeDelete: true)
                .Index(t => t.DadosProdutoId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.TbProduto", "DadosProdutoId", "dbo.Estoques");
            DropIndex("dbo.TbProduto", new[] { "DadosProdutoId" });
            DropTable("dbo.TbProduto");
            DropTable("dbo.Estoques");
        }
    }
}
