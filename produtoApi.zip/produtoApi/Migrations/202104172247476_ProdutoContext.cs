namespace produtoApi.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ProdutoContext : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.Estoques", newName: "TbEstoque");
            DropForeignKey("dbo.TbProduto", "DadosProdutoId", "dbo.Estoques");
            DropIndex("dbo.TbProduto", new[] { "DadosProdutoId" });
            AddColumn("dbo.TbEstoque", "ProdutoId", c => c.Int(nullable: false));
            AddColumn("dbo.TbProduto", "Modelo", c => c.String(maxLength: 200));
            AddColumn("dbo.TbProduto", "ContentTYPE", c => c.String(nullable: false));
            AddColumn("dbo.TbProduto", "Imagem", c => c.Binary(nullable: false));
            DropColumn("dbo.TbProduto", "ModeloProduto");
            DropColumn("dbo.TbProduto", "DadosProdutoId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.TbProduto", "DadosProdutoId", c => c.Int(nullable: false));
            AddColumn("dbo.TbProduto", "ModeloProduto", c => c.String(maxLength: 200));
            DropColumn("dbo.TbProduto", "Imagem");
            DropColumn("dbo.TbProduto", "ContentTYPE");
            DropColumn("dbo.TbProduto", "Modelo");
            DropColumn("dbo.TbEstoque", "ProdutoId");
            CreateIndex("dbo.TbProduto", "DadosProdutoId");
            AddForeignKey("dbo.TbProduto", "DadosProdutoId", "dbo.Estoques", "DadosProdutoId", cascadeDelete: true);
            RenameTable(name: "dbo.TbEstoque", newName: "Estoques");
        }
    }
}
